const express = require('express');
const fetch   = require('node-fetch');
const cors    = require('cors');
const path    = require('path');
const { parseNFCe } = require('./parser');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Headers para simular browser e evitar bloqueio
const BROWSER_HEADERS = {
  'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
  'Accept-Encoding': 'gzip, deflate, br',
  'Cache-Control':   'no-cache',
  'Pragma':          'no-cache',
  'Upgrade-Insecure-Requests': '1',
};

app.post('/api/consultar', async (req, res) => {
  const { url } = req.body;

  if (!url || !url.startsWith('http')) {
    return res.status(400).json({ erro: 'URL inválida.' });
  }

  // Valida domínio — aceita apenas Sefaz SP e domínios de NFC-e
  const allowed = ['nfce.fazenda.sp.gov.br', 'www.nfce.fazenda.sp.gov.br', 'nfe.fazenda.sp.gov.br'];
  try {
    const hostname = new URL(url).hostname;
    if (!allowed.includes(hostname)) {
      return res.status(400).json({ erro: `Domínio não permitido: ${hostname}. Use URLs da Sefaz SP.` });
    }
  } catch {
    return res.status(400).json({ erro: 'URL malformada.' });
  }

  try {
    const response = await fetch(url, {
      headers: BROWSER_HEADERS,
      timeout: 15000,
      redirect: 'follow',
    });

    if (!response.ok) {
      return res.status(502).json({
        erro: `Sefaz SP retornou erro ${response.status}. A URL pode ter expirado.`
      });
    }

    const html = await response.text();

    if (!html || html.length < 100) {
      return res.status(502).json({ erro: 'Resposta vazia da Sefaz SP.' });
    }

    // Detecta páginas de erro comuns da Sefaz
    if (/QR Code inválido|NFC-e não encontrada|Erro na consulta/i.test(html)) {
      return res.status(404).json({ erro: 'NFC-e não encontrada ou QR Code expirado.' });
    }

    const dados = parseNFCe(html);

    // Validação mínima
    if (!dados.emitente?.nome && !dados.chave) {
      return res.status(422).json({
        erro: 'Não foi possível extrair dados. O layout da página pode ter mudado.',
        html_snippet: html.slice(0, 500)
      });
    }

    return res.json(dados);

  } catch (err) {
    if (err.type === 'request-timeout') {
      return res.status(504).json({ erro: 'Timeout: Sefaz SP demorou muito para responder.' });
    }
    return res.status(500).json({ erro: err.message });
  }
});

// Catch-all para SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ NFC-e Leitor rodando em http://localhost:${PORT}`);
});
