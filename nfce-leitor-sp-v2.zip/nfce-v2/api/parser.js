const cheerio = require('cheerio');

/**
 * Extrai todos os dados de uma NFC-e SP a partir do HTML da página de consulta.
 * Tenta múltiplos seletores para ser resiliente a variações de layout.
 */
function parseNFCe(html) {
  const $ = cheerio.load(html);
  const result = {};

  // ─── Helpers ───────────────────────────────────────────────────────────────

  function txt(selector) {
    return $(selector).first().text().replace(/\s+/g, ' ').trim();
  }

  function anyTxt(...selectors) {
    for (const s of selectors) {
      const t = txt(s);
      if (t) return t;
    }
    return '';
  }

  function parseValor(str) {
    // "Vl. Total 403,10" → "403,10"
    return str.replace(/.*?(\d[\d.,]+)\s*$/, '$1').trim();
  }

  function extractRegex(str, pattern) {
    const m = str.match(pattern);
    return m ? m[1].trim() : '';
  }

  // ─── Emitente ───────────────────────────────────────────────────────────────
  result.emitente = {
    nome: anyTxt('h4', '.txtTit', '#u10', '.nomeEmit', 'h3'),
    cnpj: anyTxt('#u20 span', '#u20', '.cnpj'),
    endereco: anyTxt('#u40', '#u30', '.enderecoEmit'),
  };

  // Limpa CNPJ — remove label se vier junto
  result.emitente.cnpj = result.emitente.cnpj.replace(/cnpj[:\s]*/i, '').trim();

  // ─── Número, série, data ────────────────────────────────────────────────────
  const infoGeral = anyTxt('#u85', '#infos', '.infosNota', '.txtCont');
  result.numero  = extractRegex(infoGeral, /N[úu]mero[:\s]+(\d+)/i);
  result.serie   = extractRegex(infoGeral, /S[ée]rie[:\s]+(\d+)/i);
  result.data    = extractRegex(infoGeral, /Emiss[aã]o[:\s]+([\d\/\s:]+)/i).trim();

  // Fallback: spans individuais com classes
  if (!result.numero) result.numero = anyTxt('.nNF', '#nNF', '[id*="numero"]');
  if (!result.data)   result.data   = anyTxt('.dEmi', '#dEmi', '[id*="emissao"]');

  // ─── Chave de acesso ────────────────────────────────────────────────────────
  result.chave = anyTxt('#chaveAcesso', '.chaveAcesso', '#u105', '[id*="chave"]');
  if (!result.chave) {
    // Busca por padrão: 44 dígitos (às vezes vem sem espaços, às vezes com)
    $('*').each((_, el) => {
      const t = $(el).text().replace(/\s/g, '');
      if (!result.chave && /^\d{44}$/.test(t)) {
        result.chave = t.match(/.{4}/g).join(' ');
      }
    });
  }

  // ─── Protocolo ──────────────────────────────────────────────────────────────
  const protocoloRaw = anyTxt('#u90', '#protAutorizacao', '[id*="protocol"]', '.protAutorizacao');
  result.protocolo = extractRegex(protocoloRaw, /^(\d+)/) || protocoloRaw.split(' ')[0];

  // ─── Itens ──────────────────────────────────────────────────────────────────
  result.itens = [];

  // Tenta tabela principal
  const linhasTabela = $('#tabResult tr, table.toItens tr, .itens tr, table tr').toArray();

  linhasTabela.forEach(row => {
    const cells = $(row).find('td');
    if (cells.length < 2) return;

    const descCell = $(cells[0]).text().replace(/\s+/g, ' ').trim();
    const valorCell = $(cells[cells.length - 1]).text().replace(/\s+/g, ' ').trim();

    // Ignora linhas de cabeçalho
    if (/descrição|produto|item|código/i.test(descCell)) return;
    if (!descCell || descCell.length < 2) return;

    const item = {};

    // Descrição e código: "DIESEL S-10 COMUM (Código: 6)"
    item.descricao = descCell.replace(/\(C[oó]digo.*?\)/i, '').replace(/Qtde\..*$/i, '').trim();
    item.codigo    = extractRegex(descCell, /C[oó]digo[:\s]+(\w+)/i);
    item.qtd       = extractRegex(descCell, /Qtde?\.[:\s]*([\d,\.]+)/i);
    item.un        = extractRegex(descCell, /UN[:\s]+([A-Z]+)/i);
    item.vl_unit   = extractRegex(descCell, /Vl?\.\s*Unit\.[:\s]*([\d,\.]+)/i);
    item.vl_total  = parseValor(valorCell);

    if (item.descricao && item.vl_total) {
      result.itens.push(item);
    }
  });

  // ─── Totais ─────────────────────────────────────────────────────────────────
  result.totais = {
    qtd_itens: anyTxt('#u60', '.qtdItens', '[id*="qtd"]'),
    total:     anyTxt('#u70', '.totalNota', '#totalNota', '[id*="total"]').replace(/[^\d,]/g, '') || '',
    desconto:  anyTxt('#u64', '.desconto', '[id*="desconto"]'),
  };

  if (!result.totais.total) {
    // Busca "Valor a pagar R$: 503,09" no texto
    $('*').each((_, el) => {
      if (result.totais.total) return;
      const t = $(el).clone().children().remove().end().text();
      const m = t.match(/Valor\s+a\s+pagar\s+R\$[:\s]*([\d,\.]+)/i);
      if (m) result.totais.total = m[1];
    });
  }

  // ─── Pagamentos ─────────────────────────────────────────────────────────────
  result.pagamentos = [];

  // Tenta container de pagamento
  const pagContainers = ['#u80', '#listaFormaPagamento', '.formaPagamento', '#pagamento'];
  let pagHtml = '';
  for (const sel of pagContainers) {
    if ($(sel).length) { pagHtml = sel; break; }
  }

  if (pagHtml) {
    // Pares de spans: [tipo, valor]
    const spans = $(pagHtml).find('span, td, div');
    const texts = spans.toArray()
      .map(el => $(el).clone().children().remove().end().text().trim())
      .filter(t => t.length > 0);

    for (let i = 0; i < texts.length - 1; i++) {
      const tipo  = texts[i];
      const valor = texts[i + 1];
      if (tipo && /[\d,]/.test(valor) && !/[\d,]/.test(tipo.replace(/\./g,''))) {
        result.pagamentos.push({ tipo, valor });
        i++;
      }
    }
  }

  // Fallback: busca "Forma de pagamento" no HTML geral
  if (!result.pagamentos.length) {
    const bodyText = $('body').text();
    const pagSection = bodyText.match(/Forma de pagamento[\s\S]*?(?=Troco|Tributos|Informa)/i);
    if (pagSection) {
      const lines = pagSection[0].split('\n').map(s => s.trim()).filter(Boolean);
      for (let i = 1; i < lines.length - 1; i += 2) {
        if (lines[i] && lines[i+1] && /[\d,]/.test(lines[i+1])) {
          result.pagamentos.push({ tipo: lines[i], valor: lines[i+1] });
        }
      }
    }
  }

  // ─── Consumidor ─────────────────────────────────────────────────────────────
  const consContainer = $('#u100, #u110, .dadosConsumidor, #consumidor').first();
  const consText = consContainer.text().replace(/\s+/g, ' ').trim();

  result.consumidor = {
    cnpj_cpf:  extractRegex(consText, /(?:CNPJ|CPF)[:\s]*([\d.\/\-]+)/i),
    nome:      extractRegex(consText, /Raz[aã]o\s+Social[:\s]+([^,\n]+)/i) ||
               extractRegex(consText, /Nome[:\s]+([^\n,]+)/i),
    endereco:  extractRegex(consText, /Logradouro[:\s]+([^\n]+)/i) || '',
  };

  // Endereço: pega último trecho longo do container se não achou via label
  if (!result.consumidor.endereco) {
    const parts = consText.split(/\n|,/).map(s => s.trim()).filter(s => s.length > 15);
    result.consumidor.endereco = parts[parts.length - 1] || '';
  }

  // ─── Tributos ────────────────────────────────────────────────────────────────
  const tribText = anyTxt('#u82', '.totalTrib', '[id*="tributo"]');
  const infoText = anyTxt('#u120', '#infAdic', '.infAdic', '[id*="infAd"]');

  result.tributos = { total: tribText };
  const fedM = infoText.match(/R\$[:\s]*([\d,\.]+)\s*Federal/i);
  const estM = infoText.match(/e\s*([\d,\.]+)\s*Estadual/i);
  if (fedM) result.tributos.federal  = fedM[1];
  if (estM) result.tributos.estadual = estM[1];

  // ─── Info adicionais ────────────────────────────────────────────────────────
  result.info_adicionais = infoText;

  // Extrai campos estruturados das info adicionais
  if (infoText) {
    const placa    = infoText.match(/Placa[:\s]+([A-Z0-9]+)/i);
    const km       = infoText.match(/KM[:\s]+([\d]+)/i);
    const veiculo  = infoText.match(/Ve[íi]culo[:\s]+([^;]+)/i);
    const condutor = infoText.match(/Condutor[:\s]+([^;]+)/i);
    const vendedor = infoText.match(/Vendedor[:\s]+([^;]+)/i);

    result.extras = {
      veiculo:  veiculo  ? veiculo[1].trim()  : '',
      placa:    placa    ? placa[1].trim()    : '',
      km:       km       ? km[1].trim()       : '',
      condutor: condutor ? condutor[1].trim() : '',
      vendedor: vendedor ? vendedor[1].trim() : '',
    };
  }

  return result;
}

module.exports = { parseNFCe };
