const cheerio = require('cheerio');

const BROWSER_HEADERS = {
  'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'pt-BR,pt;q=0.9',
  'Cache-Control':   'no-cache',
};

function parseNFCe(html) {
  const $ = cheerio.load(html);

  function txt(selector) {
    return $(selector).first().text().replace(/\s+/g, ' ').trim();
  }
  function anyTxt(...selectors) {
    for (const s of selectors) { const t = txt(s); if (t) return t; }
    return '';
  }
  function extractRegex(str, pattern) {
    const m = str.match(pattern);
    return m ? m[1].trim() : '';
  }
  function parseValor(str) {
    return str.replace(/.*?(\d[\d.,]+)\s*$/, '$1').trim();
  }

  const result = {};

  result.emitente = {
    nome:     anyTxt('h4', '.txtTit', '#u10'),
    cnpj:     anyTxt('#u20 span', '#u20').replace(/cnpj[:\s]*/i, '').trim(),
    endereco: anyTxt('#u40', '#u30'),
  };

  const infoGeral = anyTxt('#u85', '#infos', '.infosNota');
  result.numero   = extractRegex(infoGeral, /N[úu]mero[:\s]+(\d+)/i);
  result.serie    = extractRegex(infoGeral, /S[ée]rie[:\s]+(\d+)/i);
  result.data     = extractRegex(infoGeral, /Emiss[aã]o[:\s]+([\d\/\s:]+)/i).trim();

  result.chave = anyTxt('#chaveAcesso', '.chaveAcesso', '#u105');
  if (!result.chave) {
    $('*').each((_, el) => {
      const t = $(el).text().replace(/\s/g, '');
      if (!result.chave && /^\d{44}$/.test(t)) {
        result.chave = t.match(/.{4}/g).join(' ');
      }
    });
  }

  const protocoloRaw = anyTxt('#u90', '#protAutorizacao');
  result.protocolo = extractRegex(protocoloRaw, /^(\d+)/) || protocoloRaw.split(' ')[0];

  result.itens = [];
  $('#tabResult tr, table.toItens tr, .itens tr').each((_, row) => {
    const cells = $(row).find('td');
    if (cells.length < 2) return;
    const descCell  = $(cells[0]).text().replace(/\s+/g, ' ').trim();
    const valorCell = $(cells[cells.length - 1]).text().replace(/\s+/g, ' ').trim();
    if (/descrição|produto|item/i.test(descCell) || !descCell) return;
    result.itens.push({
      descricao: descCell.replace(/\(C[oó]digo.*?\)/i, '').replace(/Qtde\..*$/i, '').trim(),
      codigo:    extractRegex(descCell, /C[oó]digo[:\s]+(\w+)/i),
      qtd:       extractRegex(descCell, /Qtde?\.[:\s]*([\d,\.]+)/i),
      un:        extractRegex(descCell, /UN[:\s]+([A-Z]+)/i),
      vl_unit:   extractRegex(descCell, /Vl?\.\s*Unit\.[:\s]*([\d,\.]+)/i),
      vl_total:  parseValor(valorCell),
    });
  });

  result.totais = {
    qtd_itens: anyTxt('#u60', '.qtdItens'),
    total:     anyTxt('#u70', '.totalNota').replace(/[^\d,]/g, ''),
  };

  result.pagamentos = [];
  const pagSel = ['#u80', '#listaFormaPagamento', '.formaPagamento'].find(s => $(s).length);
  if (pagSel) {
    const texts = $(pagSel).find('span, td').toArray()
      .map(el => $(el).clone().children().remove().end().text().trim())
      .filter(t => t.length > 0);
    for (let i = 0; i < texts.length - 1; i++) {
      const tipo = texts[i], valor = texts[i + 1];
      if (tipo && /[\d,]/.test(valor) && !/[\d,]/.test(tipo.replace(/\./g, ''))) {
        result.pagamentos.push({ tipo, valor });
        i++;
      }
    }
  }

  const consText = anyTxt('#u100, #u110, .dadosConsumidor');
  result.consumidor = {
    cnpj_cpf: extractRegex(consText, /(?:CNPJ|CPF)[:\s]*([\d.\/\-]+)/i),
    nome:     extractRegex(consText, /Raz[aã]o\s+Social[:\s]+([^,\n]+)/i),
    endereco: extractRegex(consText, /Logradouro[:\s]+([^\n]+)/i),
  };

  const tribText = anyTxt('#u82', '.totalTrib');
  const infoText = anyTxt('#u120', '#infAdic', '.infAdic');
  result.tributos = {
    total:    tribText,
    federal:  extractRegex(infoText, /R\$[:\s]*([\d,\.]+)\s*Federal/i),
    estadual: extractRegex(infoText, /e\s*([\d,\.]+)\s*Estadual/i),
  };

  result.info_adicionais = infoText;
  result.extras = {
    veiculo:  extractRegex(infoText, /Ve[íi]culo[:\s]+([^;]+)/i),
    placa:    extractRegex(infoText, /Placa[:\s]+([A-Z0-9]+)/i),
    km:       extractRegex(infoText, /KM[:\s]+([\d]+)/i),
    condutor: extractRegex(infoText, /Condutor[:\s]+([^;]+)/i),
    vendedor: extractRegex(infoText, /Vendedor[:\s]+([^;]+)/i),
  };

  return result;
}

exports.handler = async (event) => {
  const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };

  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ erro: 'Método não permitido' }) };

  const { url } = JSON.parse(event.body || '{}');
  if (!url || !url.startsWith('http')) return { statusCode: 400, headers, body: JSON.stringify({ erro: 'URL inválida.' }) };

  const allowed = ['nfce.fazenda.sp.gov.br', 'www.nfce.fazenda.sp.gov.br'];
  try {
    if (!allowed.includes(new URL(url).hostname))
      return { statusCode: 400, headers, body: JSON.stringify({ erro: 'Domínio não permitido.' }) };
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ erro: 'URL malformada.' }) };
  }

  try {
    const response = await fetch(url, { headers: BROWSER_HEADERS });
    if (!response.ok) return { statusCode: 502, headers, body: JSON.stringify({ erro: `Sefaz SP retornou ${response.status}.` }) };

    const html = await response.text();
    if (/QR Code inválido|NFC-e não encontrada/i.test(html))
      return { statusCode: 404, headers, body: JSON.stringify({ erro: 'NFC-e não encontrada ou expirada.' }) };

    const dados = parseNFCe(html);
    return { statusCode: 200, headers, body: JSON.stringify(dados) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ erro: err.message }) };
  }
};
